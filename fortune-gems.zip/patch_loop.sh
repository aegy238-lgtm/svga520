sed -i "s/'-i', audioName,/'-stream_loop', '-1', '-i', audioName,/g" src/components/MultiSvgaViewer.tsx
