const fs = require('fs');
let content = fs.readFileSync('src/components/MultiSvgaViewer.tsx', 'utf8');

content = content.replace(
  /import \{ Muxer, ArrayBufferTarget \} from 'mp4-muxer';/,
  `import { Muxer as Mp4Muxer, ArrayBufferTarget as Mp4ArrayBufferTarget } from 'mp4-muxer';
import { Muxer as WebMMuxer, ArrayBufferTarget as WebmArrayBufferTarget } from 'webm-muxer';`
);

// Also I noticed in WebMMuxer initialization, for some reason I wrote it as `new Mp4Muxer` and it's throwing error TS2351.
// Let's check the typings. Mp4Muxer and WebMMuxer. They might be named `Muxer` in their respective packages.
// Let's also check the cast on `muxer.target as ArrayBufferTarget`.
content = content.replace(
  /muxer\.target as ArrayBufferTarget/g,
  `muxer.target as Mp4ArrayBufferTarget | WebmArrayBufferTarget`
);

fs.writeFileSync('src/components/MultiSvgaViewer.tsx', content);
