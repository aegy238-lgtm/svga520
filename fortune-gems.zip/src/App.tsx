import React, { useState, useCallback, useEffect, useRef, Suspense, lazy } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Header } from './components/Header';
import { FeaturesGuideModal } from './components/FeaturesGuideModal';
import { Uploader } from './components/Uploader';
import { Dashboard } from './components/Dashboard';

// Lazy load heavy tools to drastically reduce initial bundle size
const Workspace = lazy(() => import('./components/Workspace').then(m => ({ default: m.Workspace })));
const BatchCompressor = lazy(() => import('./components/BatchCompressor').then(m => ({ default: m.BatchCompressor })));
const BatchCropper = lazy(() => import('./components/BatchCropper').then(m => ({ default: m.BatchCropper })));
const VideoConverter = lazy(() => import('./components/VideoConverter').then(m => ({ default: m.VideoConverter })));
const UniversalMotionTools = lazy(() => import('./components/UniversalMotionTools').then(m => ({ default: m.UniversalMotionTools })));
const MultiSvgaViewer = lazy(() => import('./components/MultiSvgaViewer').then(m => ({ default: m.MultiSvgaViewer })));
const ImageToSvga = lazy(() => import('./components/ImageToSvga').then(m => ({ default: m.ImageToSvga })));
const ImageProcessor = lazy(() => import('./components/ImageProcessor').then(m => ({ default: m.ImageProcessor })));
const ImageEnhancer = lazy(() => import('./components/ImageEnhancer').then(m => ({ default: m.ImageEnhancer })));
const BatchImageProcessor = lazy(() => import('./components/BatchImageProcessor').then(m => ({ default: m.BatchImageProcessor })));
const BatchImageConverter = lazy(() => import('./components/BatchImageConverter').then(m => ({ default: m.BatchImageConverter })));
const PagToSvgaStudio = lazy(() => import('./components/PagToSvgaStudio').then(m => ({ default: m.PagToSvgaStudio })));
const SvgaBatchCompressor = lazy(() => import('./components/SvgaBatchCompressor').then(m => ({ default: m.SvgaBatchCompressor })));
const SvgaLayerEditor = lazy(() => import('./components/SvgaLayerEditor/SvgaLayerEditor').then(m => ({ default: m.SvgaLayerEditor })));
const ImageEditor = lazy(() => import('./components/ImageEditor').then(m => ({ default: m.ImageEditor })));
const Name3DEditor = lazy(() => import('./components/Name3DEditor/Name3DEditor'));
const ImageMatcher = lazy(() => import('./components/ImageMatcher').then(m => ({ default: m.ImageMatcher })));
const AudioExtractor = lazy(() => import('./components/AudioExtractor').then(m => ({ default: m.AudioExtractor })));
const AIVideoMattingStudio = lazy(() => import('./components/AIVideoMattingStudio').then(m => ({ default: m.AIVideoMattingStudio })));
const AnimationManager = lazy(() => import('./components/AnimationManager/AnimationManager').then(m => ({ default: m.AnimationManager })));
const AdminPanel = lazy(() => import('./components/AdminPanel').then(m => ({ default: m.AdminPanel })));


import { Login } from './components/Auth/Login';
import { Signup } from './components/Auth/Signup';
import { Loading } from './components/Auth/Loading';
import { UserProfileModal } from './components/UserProfileModal';
import { SubscriptionModal } from './components/SubscriptionModal';
import { useAuth } from './contexts/AuthContext';
import { AppState, FileMetadata, AppSettings } from './types';
import { useAccessControl } from './hooks/useAccessControl';
import { doc, getDoc, onSnapshot, updateDoc, setDoc } from 'firebase/firestore';
import { db } from './lib/firebase';
import { logActivity } from './utils/logger';
import { MaintenanceScreen } from './components/MaintenanceScreen';
import { VersionBlockedModal } from './components/Auth/VersionBlockedModal';
import { checkVersionCompatibility, verifyAccountVersionWithServer, getActiveClientVersion } from './utils/versionControl';
import { AppUpdateToast } from './components/AppUpdateToast';
import { extractSvgaFromPdfFile } from './utils/pdfSvgaExtractor';

declare var SVGA: any;

import { OnboardingModal } from './components/OnboardingModal';
import { HelpCircle, BookOpen, Wrench, AlertTriangle, ShieldAlert } from 'lucide-react';
import { ErrorBoundary } from './components/ErrorBoundary';

const videoWidth = 1334;
const videoHeight = 750;

const App: React.FC = () => {
  const { currentUser, loading, logout } = useAuth();
  const { checkAccess } = useAccessControl();
  const [state, setState] = useState<AppState>(AppState.IDLE);
  const [fileMetadata, setFileMetadata] = useState<FileMetadata | null>(null);
  const [batchFiles, setBatchFiles] = useState<File[]>([]);
  const [settings, setSettings] = useState<AppSettings | null>(() => {
    const cached = localStorage.getItem('appSettings');
    return cached ? JSON.parse(cached) : null;
  });
  const [isQuotaExceeded, setIsQuotaExceeded] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showFeaturesGuide, setShowFeaturesGuide] = useState(false);
  const [showWelcomeGuide, setShowWelcomeGuide] = useState(false);
  const [showBatchImage, setShowBatchImage] = useState(false);
  const [uploadedPagFile, setUploadedPagFile] = useState<File | null>(null);
  const [layerEditorInitialFile, setLayerEditorInitialFile] = useState<File | null>(null);
  const [globalQuality, setGlobalQuality] = useState<'low' | 'medium' | 'high'>('high');
  const [initialLottieFile, setInitialLottieFile] = useState<File | null>(null);
  const [initialVapFile, setInitialVapFile] = useState<File | null>(null);
  const [initialVideoFiles, setInitialVideoFiles] = useState<File[]>([]);
  const [initialSvgaFiles, setInitialSvgaFiles] = useState<File[]>([]);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [showSplash, setShowSplash] = useState(true);

  // Prefetch lazy-loaded components and heavy engines silently in the background
  useEffect(() => {
    // Immediately prefetch core parser libraries in the background
    if ('requestIdleCallback' in window) {
      (window as any).requestIdleCallback(() => {
        import('svga.lite').catch(() => {});
        import('protobufjs').catch(() => {});
        import('pako').catch(() => {});
      });
    } else {
      setTimeout(() => {
        import('svga.lite').catch(() => {});
        import('protobufjs').catch(() => {});
        import('pako').catch(() => {});
      }, 500);
    }

    const timer = setTimeout(() => {
      const loadModules = [
        () => import('./components/Workspace'),
        () => import('./components/BatchCompressor'),
        () => import('./components/BatchCropper'),
        () => import('./components/VideoConverter'),
        () => import('./components/UniversalMotionTools'),
        () => import('./components/MultiSvgaViewer'),
        () => import('./components/ImageToSvga'),
        () => import('./components/ImageProcessor'),
        () => import('./components/ImageEnhancer'),
        () => import('./components/BatchImageProcessor'),
        () => import('./components/BatchImageConverter'),
        () => import('./components/PagToSvgaStudio'),
        () => import('./components/SvgaBatchCompressor'),
        () => import('./components/SvgaLayerEditor/SvgaLayerEditor'),
        () => import('./components/ImageEditor'),
        () => import('./components/Name3DEditor/Name3DEditor'),
        () => import('./components/ImageMatcher'),
        () => import('./components/AudioExtractor'),
        () => import('./components/AIVideoMattingStudio'),
        () => import('./components/AnimationManager/AnimationManager'),
        () => import('./components/AdminPanel')
      ];

      let i = 0;
      const staggerLoad = () => {
        if (i < loadModules.length) {
          if ('requestIdleCallback' in window) {
            (window as any).requestIdleCallback(() => {
              loadModules[i]().catch(() => {});
              i++;
              staggerLoad();
            });
          } else {
            setTimeout(() => {
              loadModules[i]().catch(() => {});
              i++;
              staggerLoad();
            }, 200);
          }
        }
      };
      staggerLoad();
    }, 2000); // Wait 2 seconds after initial render before background loading

    return () => clearTimeout(timer);
  }, []);

  // Server-Enforced Version Control State
  const [versionBlockedState, setVersionBlockedState] = useState<{
    isBlocked: boolean;
    requiredVersion: string;
    installedVersion: string;
  }>({
    isBlocked: false,
    requiredVersion: 'v3.0.0',
    installedVersion: 'v3.0.0'
  });

  // Ensure user always lands directly on the SVGA Editor / Dashboard home screen

  useEffect(() => {
    if (!currentUser) {
      setVersionBlockedState(prev => ({ ...prev, isBlocked: false }));
      return;
    }

    const clientVer = getActiveClientVersion();

    // CRITICAL: Admins are ALWAYS bypassed from version blocks to prevent lockouts.
    // We also correct database records if they were set incorrectly.
    if (currentUser.role === 'admin') {
      setVersionBlockedState(prev => ({ ...prev, isBlocked: false }));
      
      // Self-correct database if allowedVersion is not set to client version
      if (currentUser.allowedVersion !== clientVer) {
        updateDoc(doc(db, 'users', currentUser.id), {
          allowedVersion: clientVer,
          lastUsedVersion: clientVer
        }).catch(err => console.warn("Failed to correct admin allowedVersion:", err));
      }

      // Self-correct global default allowed version in settings
      if (settings && settings.defaultAllowedVersion !== clientVer) {
        updateDoc(doc(db, 'settings', 'global'), {
          defaultAllowedVersion: clientVer
        }).catch(err => console.warn("Failed to correct global defaultAllowedVersion:", err));
      }
      return;
    }

    const allowedVer = currentUser.allowedVersion || settings?.defaultAllowedVersion || 'v3.0.0';

    const localCheck = checkVersionCompatibility(allowedVer, clientVer);
    if (!localCheck.isAllowed) {
      setVersionBlockedState({
        isBlocked: true,
        requiredVersion: localCheck.requiredVersion,
        installedVersion: localCheck.currentVersion
      });
      return;
    }

    verifyAccountVersionWithServer(currentUser.id, currentUser.email, allowedVer)
      .then(res => {
        if (!res.allowed) {
          setVersionBlockedState({
            isBlocked: true,
            requiredVersion: res.requiredVersion,
            installedVersion: res.installedVersion
          });
        } else {
          setVersionBlockedState(prev => ({ ...prev, isBlocked: false }));
          // Update lastUsedVersion in database if it differs to show real-time version status to admins
          if (currentUser.lastUsedVersion !== clientVer) {
            updateDoc(doc(db, 'users', currentUser.id), {
              lastUsedVersion: clientVer
            }).catch(err => console.warn("Failed to update lastUsedVersion on success:", err));
          }
        }
      })
      .catch(() => {
        if (!localCheck.isAllowed) {
          setVersionBlockedState({
            isBlocked: true,
            requiredVersion: localCheck.requiredVersion,
            installedVersion: localCheck.currentVersion
          });
        } else {
          setVersionBlockedState(prev => ({ ...prev, isBlocked: false }));
          if (currentUser.lastUsedVersion !== clientVer) {
            updateDoc(doc(db, 'users', currentUser.id), {
              lastUsedVersion: clientVer
            }).catch(err => console.warn("Failed to update lastUsedVersion on local success:", err));
          }
        }
      });
  }, [currentUser?.id, currentUser?.role, currentUser?.allowedVersion, settings?.defaultAllowedVersion]);

  useEffect(() => {
    // Show splash screen for 2.8 seconds on startup, then smoothly fade out
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2800);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    // Check if user has seen onboarding
    const hasSeenOnboarding = localStorage.getItem('hasSeenOnboarding');
    if (!hasSeenOnboarding) {
      setShowOnboarding(true);
    }
  }, []);

  useEffect(() => {
    const guideSkipped = localStorage.getItem('guide_skipped');
    if (!guideSkipped) {
      setShowWelcomeGuide(true);
    }
  }, []);

  const handleCloseOnboarding = () => {
    setShowOnboarding(false);
    localStorage.setItem('hasSeenOnboarding', 'true');
  };

  const isSuperAdmin = currentUser?.email?.toLowerCase() === 'uhbijnokmpl098900@gmail.com' || currentUser?.email?.toLowerCase() === 'aegy238@gmail.com' || currentUser?.isSuperAdmin === true;
  const isAdminUser = isSuperAdmin || currentUser?.role === 'admin' || currentUser?.role === 'moderator';
  const isMaintenanceActive = Boolean(settings?.isMaintenanceMode);

  // Check if current user is explicitly allowed to use the app during server outage/maintenance
  const isUserExemptFromOutage = Boolean(
    isAdminUser ||
    currentUser?.canBypassMaintenance === true ||
    (currentUser?.id && Array.isArray(settings?.maintenanceAllowedUserIds) && settings.maintenanceAllowedUserIds.includes(currentUser.id)) ||
    (currentUser?.email && Array.isArray(settings?.maintenanceAllowedEmails) && settings.maintenanceAllowedEmails.some(e => e.toLowerCase() === currentUser.email?.toLowerCase()))
  );

  useEffect(() => {
    // Real-time listener for Global Settings
    const docRef = doc(db, 'settings', 'global');
    const unsubscribe = onSnapshot(docRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data() as AppSettings;
        setSettings(data);
        localStorage.setItem('appSettings', JSON.stringify(data));
        // Sync with backend memory cache
        try {
          fetch('/api/maintenance/sync', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              isMaintenanceMode: data.isMaintenanceMode,
              maintenanceMessage: data.maintenanceMessage,
              maintenanceTitle: data.maintenanceTitle,
              maintenanceEstimatedTime: data.maintenanceEstimatedTime
            })
          }).catch(() => {});
        } catch (e) {}
      }
    }, (e: any) => {
      console.warn("Settings Load Notice:", e.message);
      const cached = localStorage.getItem('appSettings');
      if (cached) {
        try {
          setSettings(JSON.parse(cached));
        } catch (parseError) {
          console.error("Failed to parse cached settings");
        }
      }
    });

    return () => unsubscribe();
  }, []);

  const handleFeatureAccess = async (targetState: AppState, featureName: string) => {
    // 1. Check Feature Access Control (تحديد الوظائف)
    if (currentUser) {
      const stateToActionKey: Record<string, string> = {
        [AppState.AI_VIDEO_MATTING]: 'aiVideoMatting',
        [AppState.ANIMATION_MANAGER]: 'animationManager',
        [AppState.VIDEO_CONVERTER]: 'videoConverter',
        [AppState.UNIVERSAL_CONVERTER]: 'universalConverter',
        [AppState.MULTI_SVGA_VIEWER]: 'multiSvga',
        [AppState.BATCH_IMAGE_PROCESSOR]: 'batchImageProcessor',
        [AppState.SVGA_BATCH_COMPRESSOR]: 'svgaBatchCompressor',
        [AppState.SVGA_LAYER_EDITOR]: 'svgaLayerEditor',
        [AppState.BATCH_COMPRESSOR]: 'batchCompress',
        [AppState.BATCH_CROPPER]: 'batchCropper',
        [AppState.IMAGE_CONVERTER]: 'imageConverter',
        [AppState.SVGA_EDITOR_EX]: 'svgaEx',
        [AppState.IMAGE_PROCESSOR]: 'imageProcessor',
        [AppState.IMAGE_MATCHER]: 'imageMatcher',
        [AppState.IMAGE_EDITOR]: 'imageEditor',
        [AppState.IMAGE_ENHANCER]: 'imageEnhancer',
        [AppState.NAME_3D_EDITOR]: 'name3DEditor',
        [AppState.AUDIO_EXTRACTOR]: 'audioExtractor'
      };

      const actionKey = stateToActionKey[targetState];
      if (actionKey && currentUser.allFeaturesEnabled === false) {
        const allowed = currentUser.allowedFeatures || [];
        if (!allowed.includes(actionKey)) {
          alert("عذراً، هذه الوظيفة غير متاحة في حسابك بناءً على صلاحياتك المحددة.");
          return;
        }
      }
    }

    // 2. Check Subscription/Credits Access
    const { allowed } = await checkAccess(featureName, { decrement: false });
    if (allowed) {
      setState(targetState);
    } else {
      setShowSubscriptionModal(true);
    }
  };

  const handleImageConverterOpen = (file?: File) => {
    if (file) setInitialLottieFile(file);
    handleFeatureAccess(AppState.IMAGE_CONVERTER, 'Image Converter');
  };

  const handleFileUpload = useCallback(async (files: File[], uploadMode?: string) => {
    if (files.length === 0) return;

    // Direct routing for explicit Batch Modes
    if (uploadMode === 'batch-mp4') {
      setInitialVideoFiles(files);
      handleFeatureAccess(AppState.VIDEO_CONVERTER, 'Video Converter');
      return;
    }

    if (uploadMode === 'batch-svga') {
      setInitialSvgaFiles(files);
      handleFeatureAccess(AppState.MULTI_SVGA_VIEWER, 'Multi SVGA Preview');
      return;
    }

    // Expand any PDF files (single or multiple) into their extracted SVGA files
    const expandedFiles: File[] = [];
    for (const f of files) {
      if ((f?.name || '').toLowerCase().endsWith('.pdf')) {
        try {
          const extracted = await extractSvgaFromPdfFile(f);
          if (extracted.length > 0) {
            expandedFiles.push(...extracted.map(e => e.file));
          } else {
            alert(`لم يتم العثور على ملفات SVGA صالحة داخل: ${f.name}`);
          }
        } catch (err) {
          console.error('PDF extraction failed for:', f.name, err);
          alert(`تعذر فك واستخراج ملفات SVGA من: ${f.name}`);
        }
      } else {
        expandedFiles.push(f);
      }
    }

    if (expandedFiles.length === 0) return;
    const currentFiles = expandedFiles;

    if (currentFiles.length > 1) {
      const svgaFiles = currentFiles.filter(f => (f?.name || '').toLowerCase().endsWith('.svga'));
      const videoFiles = currentFiles.filter(f => {
        const name = (f?.name || '').toLowerCase();
        return name.endsWith('.mp4') || name.endsWith('.vap') || name.endsWith('.webm') || name.endsWith('.mov');
      });

      if (svgaFiles.length === currentFiles.length || svgaFiles.length > 1) {
        setInitialSvgaFiles(currentFiles);
        handleFeatureAccess(AppState.MULTI_SVGA_VIEWER, 'Multi SVGA Preview');
        return;
      }

      if (videoFiles.length === currentFiles.length) {
        setInitialVideoFiles(currentFiles);
        handleFeatureAccess(AppState.VIDEO_CONVERTER, 'Video Converter');
        return;
      }
    }

    const file = currentFiles[0];
    const fileUrl = URL.createObjectURL(file);

    // Check for PAG file
    if ((file?.name || '').toLowerCase().endsWith('.pag')) {
      setUploadedPagFile(file);
      return;
    }

    // Check for Lottie JSON
    if ((file?.name || '').toLowerCase().endsWith('.json') || file?.type === 'application/json') {
        try {
            const text = await file.text();
            const json = JSON.parse(text);
            if (json.v && json.layers && json.fr) {
                // It's a Lottie file - redirect to Image Converter
                setInitialLottieFile(file);
                setState(AppState.IMAGE_CONVERTER);
                return;
            }
        } catch (e) {
            console.error("Not a valid Lottie JSON", e);
        }
    }

    // Log the upload activity if user exists
    if (currentUser) {
      logActivity(currentUser, 'upload', `Uploaded file: ${file.name} (${(file.size / 1024).toFixed(2)} KB)`);
    }

    const isVapOrVideo = (file?.name || '').toLowerCase().endsWith('.vap') || 
                         (file?.name || '').toLowerCase().endsWith('.mp4') || 
                         (file?.name || '').toLowerCase().endsWith('.webm') || 
                         (file?.name || '').toLowerCase().endsWith('.mov') ||
                         file?.type?.startsWith('video/');

    if (isVapOrVideo) {
      setInitialVapFile(file);
      handleFeatureAccess(AppState.UNIVERSAL_CONVERTER, 'Universal Motion Tools');
      return;
    }

    if (!file || !(file?.name || '').toLowerCase().endsWith('.svga')) {
      alert("يرجى رفع ملف بصيغة مدعومة (.svga, .vap, .mp4, .pag, .json)");
      URL.revokeObjectURL(fileUrl);
      return;
    }
    
    try {
      const parser = new SVGA.Parser();
      parser.load(fileUrl, (videoItem: any) => {
        // Robust FPS extraction
        let extractedFps = videoItem.FPS || videoItem.fps || 30;
        if (typeof extractedFps === 'string') extractedFps = parseFloat(extractedFps);
        if (!extractedFps || extractedFps <= 0) extractedFps = 30;

        const meta: FileMetadata = {
          name: file.name, size: file.size, type: 'SVGA',
          dimensions: { width: videoItem.videoSize?.width || 0, height: videoItem.videoSize?.height || 0 },
          fps: extractedFps, frames: videoItem.frames || 0, assets: [], videoItem,
          fileUrl: fileUrl,
          originalFile: file
        };
        
        setFileMetadata(meta);
        setState(AppState.PROCESSING);
      }, (err: any) => {
        console.error("SVGA Load Error:", err);
        alert("فشل في قراءة ملف SVGA.");
        URL.revokeObjectURL(fileUrl);
      });
    } catch (err) {
      setState(AppState.IDLE);
    }
  }, [currentUser, settings]);

  const handleReset = useCallback(() => {
    if (fileMetadata?.fileUrl) {
      URL.revokeObjectURL(fileMetadata.fileUrl);
    }
    setState(AppState.IDLE);
    setFileMetadata(null);
    setBatchFiles([]);
    setInitialLottieFile(null);
    setInitialVapFile(null);
    setInitialVideoFiles([]);
    setInitialSvgaFiles([]);
  }, [fileMetadata]);

  if (loading) {
    return <Loading />;
  }

  // 🔴 Maintenance Mode Blocking for Non-Exempt Users
  if (isMaintenanceActive && !isUserExemptFromOutage) {
    return (
      <MaintenanceScreen 
        settings={settings} 
        currentUser={currentUser} 
        onRefresh={async () => {
          try {
            const docSnap = await getDoc(doc(db, 'settings', 'global'));
            if (docSnap.exists()) {
              setSettings(docSnap.data() as AppSettings);
            }
          } catch (e) {}
        }}
      />
    );
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-[#020617] flex items-center justify-center p-4 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
          <div className="absolute top-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-500/10 blur-[120px] rounded-full"></div>
          <div className="absolute bottom-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-600/10 blur-[120px] rounded-full"></div>
        </div>
        <div className="relative z-10 w-full max-w-md">
          {authMode === 'login' ? (
            <Login onToggle={() => setAuthMode('signup')} />
          ) : (
            <Signup onToggle={() => setAuthMode('login')} />
          )}
        </div>
      </div>
    );
  }

  const defaultBgUrl = 'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?q=80&w=2070&auto=format&fit=crop';
  const bgUrl = settings?.backgroundUrl || defaultBgUrl;

  const dynamicBgStyle: React.CSSProperties = {
    backgroundImage: `linear-gradient(rgba(7, 10, 18, 0.85), rgba(7, 10, 18, 0.95)), url(${bgUrl})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundAttachment: 'fixed'
  };

  return (
    <div className="min-h-screen text-slate-200 overflow-x-hidden relative" style={dynamicBgStyle}>
      <div className="fixed inset-0 bg-[#020617]/30 backdrop-blur-[4px] -z-10 pointer-events-none" />
      
      {/* 3D Splash Screen */}
      
      
      {showFeaturesGuide && (
        <FeaturesGuideModal onClose={() => {
          setShowFeaturesGuide(false);
          localStorage.setItem('guide_skipped', 'true');
        }} />
      )}

      <AnimatePresence>
        {showSplash && (
          <motion.div 
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, transition: { duration: 0.8, ease: "easeInOut" } }}
            onClick={() => setShowSplash(false)}
            className="fixed inset-0 z-[2000] bg-[#020617] flex flex-col items-center justify-center cursor-pointer select-none"
            title="انقر لتخطي الإعلان والدخول فوراً"
          >
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-20 mix-blend-overlay"></div>
            
            <motion.div
              initial={{ scale: 0.5, y: 50, rotateX: 30, opacity: 0 }}
              animate={{ scale: 1, y: 0, rotateX: 0, opacity: 1 }}
              exit={{ scale: 1.1, opacity: 0, filter: 'blur(10px)' }}
              transition={{ duration: 1, type: "spring", bounce: 0.5 }}
              className="relative z-10 flex flex-col items-center"
            >
               {settings?.logoUrl ? (
                 <motion.img 
                   src={settings.logoUrl} 
                   alt="Logo" 
                   initial={{ filter: 'drop-shadow(0 0 0 rgba(99,102,241,0))' }}
                   animate={{ filter: ['drop-shadow(0 0 20px rgba(99,102,241,0.8))', 'drop-shadow(0 0 40px rgba(168,85,247,0.8))', 'drop-shadow(0 0 20px rgba(99,102,241,0.8))'] }}
                   transition={{ duration: 2, repeat: Infinity }}
                   className="w-32 h-32 md:w-48 md:h-48 object-cover rounded-3xl mb-6 shadow-2xl" 
                 />
               ) : (
                 <motion.div 
                   initial={{ filter: 'drop-shadow(0 0 0 rgba(99,102,241,0))' }}
                   animate={{ filter: ['drop-shadow(0 0 20px rgba(99,102,241,0.8))', 'drop-shadow(0 0 40px rgba(168,85,247,0.8))', 'drop-shadow(0 0 20px rgba(99,102,241,0.8))'] }}
                   transition={{ duration: 2, repeat: Infinity }}
                   className="w-32 h-32 md:w-48 md:h-48 bg-gradient-to-br from-indigo-600 via-purple-600 to-indigo-900 rounded-3xl flex items-center justify-center shadow-lg border-2 border-white/20 mb-6"
                 >
                   <span className="text-white font-black text-6xl md:text-8xl drop-shadow-lg">S</span>
                 </motion.div>
               )}
               
               <h1 className="text-4xl md:text-6xl font-black animated-brand-text tracking-tight uppercase">
                 {settings?.appName?.trim() ? settings.appName : 'SVGA Studio'}
               </h1>
               <motion.span 
                 initial={{ opacity: 0, y: 10 }}
                 animate={{ opacity: 1, y: 0 }}
                 transition={{ delay: 0.5, duration: 0.5 }}
                 className="text-xs md:text-sm text-indigo-400 font-bold tracking-[0.4em] uppercase mt-4"
               >
                 Professional Platform
               </motion.span>
               
               {/* 3D Core Loader Ring */}
               <div className="absolute inset-0 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] border-2 border-dashed border-indigo-500/30 rounded-full animate-[spin_10s_linear_infinite] -z-10"></div>
               <div className="absolute inset-0 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[140%] h-[140%] border border-purple-500/20 rounded-full animate-[spin_15s_linear_infinite_reverse] -z-10"></div>

               {/* Dismiss hint & loading bar */}
               <motion.div 
                 initial={{ opacity: 0 }}
                 animate={{ opacity: 0.8 }}
                 transition={{ delay: 1 }}
                 className="mt-8 flex flex-col items-center gap-2"
               >
                 <div className="w-36 h-1 bg-white/10 rounded-full overflow-hidden">
                   <motion.div 
                     initial={{ width: "0%" }}
                     animate={{ width: "100%" }}
                     transition={{ duration: 2.8, ease: "linear" }}
                     className="h-full bg-gradient-to-r from-indigo-500 to-cyan-400 rounded-full"
                   />
                 </div>
                 <span className="text-[10px] text-slate-400 font-mono tracking-wider">
                   انقر في أي مكان للتخطي
                 </span>
               </motion.div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {isMaintenanceActive && isAdminUser && (
        <div className="fixed top-0 left-0 right-0 bg-gradient-to-r from-rose-700 via-amber-700 to-rose-700 text-white py-1.5 px-4 text-xs font-bold z-[300] flex items-center justify-between shadow-lg border-b border-rose-500/40">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
            </span>
            <span>🔴 سيرفر التطبيق معطّل حالياً للعامة: تظهر للزوار رسالة "حالياً سيرفر التطبيق متعطل الآن" بالعربي والإنجليزي، وشغال لحساب المدير فقط.</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={async () => {
                if (window.confirm('هل أنت متأكد من إعادة تشغيل الموقع للجميع وإلغاء حالة التعطيل؟')) {
                  await setDoc(doc(db, 'settings', 'global'), { isMaintenanceMode: false }, { merge: true });
                }
              }}
              className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-black border border-emerald-400/40 transition-all shadow"
            >
              إعادة تشغيل الموقع للجميع 🟢
            </button>
            <button
              onClick={() => setState(AppState.ADMIN_PANEL)}
              className="px-3 py-1 rounded-lg bg-black/40 hover:bg-black/60 text-white text-[11px] border border-white/20 transition-all font-bold"
            >
              فتح لوحة الإعدادات
            </button>
          </div>
        </div>
      )}

      {isQuotaExceeded && (
        <div className="fixed top-0 left-0 right-0 bg-amber-500/90 backdrop-blur-sm text-black py-1 px-4 text-center text-[10px] font-bold z-[300] flex items-center justify-center gap-2">
          <span>⚠️ تم تجاوز حصة الاستخدام اليومية للسيرفر. الموقع يعمل الآن بالوضع الاحتياطي (Offline Mode).</span>
        </div>
      )}

      <Header 
        onOpenGuide={() => setShowFeaturesGuide(true)}
        onLogoClick={handleReset} 
        isAdmin={isAdminUser} 
        currentUser={currentUser}
        settings={settings}
        onAdminToggle={() => setState(AppState.ADMIN_PANEL)}
        onLogout={logout}
        isAdminOpen={state === AppState.ADMIN_PANEL}
        onBatchOpen={() => handleFeatureAccess(AppState.BATCH_COMPRESSOR, 'Batch Compressor')}
        onConverterOpen={() => handleFeatureAccess(AppState.VIDEO_CONVERTER, 'Video Converter')}
        onImageConverterOpen={() => handleImageConverterOpen()}
        onImageEditorOpen={() => handleFeatureAccess(AppState.IMAGE_EDITOR, 'Image Editor')}
        onImageMatcherOpen={() => handleFeatureAccess(AppState.IMAGE_MATCHER, 'Image Matcher')}
        onCropperOpen={() => handleFeatureAccess(AppState.BATCH_CROPPER, 'Batch Cropper')}
        onSvgaExOpen={() => handleFeatureAccess(AppState.SVGA_EDITOR_EX, 'SVGA Editor EX')}
        onMultiSvgaOpen={() => handleFeatureAccess(AppState.MULTI_SVGA_VIEWER, 'Multi SVGA Preview')}
        onImageProcessorOpen={() => handleFeatureAccess(AppState.IMAGE_PROCESSOR, 'Image Processor')}
        onImageEnhancerOpen={() => handleFeatureAccess(AppState.IMAGE_ENHANCER, 'AI Image Enhancer')}
        onBatchImageProcessorOpen={() => handleFeatureAccess(AppState.BATCH_IMAGE_PROCESSOR, 'Batch Image Processor')}
        onUniversalConverterOpen={() => handleFeatureAccess(AppState.UNIVERSAL_CONVERTER, 'Universal Motion Tools')}
        onName3DEditorOpen={() => handleFeatureAccess(AppState.NAME_3D_EDITOR, '3D Name Editor')}
        onAudioExtractorOpen={() => handleFeatureAccess(AppState.AUDIO_EXTRACTOR, 'Audio Extractor')}
        onAiVideoMattingOpen={() => handleFeatureAccess(AppState.AI_VIDEO_MATTING, 'AI Video Matting Studio')}
        onSvgaBatchCompressorOpen={() => handleFeatureAccess(AppState.SVGA_BATCH_COMPRESSOR, 'SVGA Batch Compressor')}
        onAnimationManagerOpen={() => handleFeatureAccess(AppState.ANIMATION_MANAGER, 'Animation File Manager')}
        onSvgaLayerEditorOpen={() => {
          setLayerEditorInitialFile(fileMetadata?.originalFile || null);
          handleFeatureAccess(AppState.SVGA_LAYER_EDITOR, 'SVGA Layer Editor');
        }}
        onBatchImageOpen={() => setShowBatchImage(true)}
        onLoginClick={() => {}}
        onProfileClick={() => {}}
        currentTab={
          state === AppState.ANIMATION_MANAGER ? 'animation-manager' :
          state === AppState.AI_VIDEO_MATTING ? 'ai-video-matting' :
          state === AppState.SVGA_LAYER_EDITOR ? 'svga-layer-editor' :
          state === AppState.SVGA_BATCH_COMPRESSOR ? 'svga-compressor' :
          state === AppState.BATCH_COMPRESSOR ? 'batch' : 
          state === AppState.STORE ? 'store' : 
          state === AppState.VIDEO_CONVERTER ? 'converter' : 
          state === AppState.IMAGE_CONVERTER ? 'image-converter' :
          state === AppState.IMAGE_PROCESSOR ? 'image-processor' :
          state === AppState.IMAGE_ENHANCER ? 'image-enhancer' :
          state === AppState.BATCH_IMAGE_PROCESSOR ? 'batch-image-processor' :
          state === AppState.IMAGE_EDITOR ? 'image-editor' :
          state === AppState.IMAGE_MATCHER ? 'image-matcher' :
          state === AppState.BATCH_CROPPER ? 'cropper' :
          state === AppState.SVGA_EDITOR_EX ? 'svga-ex' :
          state === AppState.MULTI_SVGA_VIEWER ? 'multi-svga' :
          state === AppState.NAME_3D_EDITOR ? 'name-3d' :
          state === AppState.AUDIO_EXTRACTOR ? 'audio-extractor' :
          state === AppState.UNIVERSAL_CONVERTER ? 'universal' :
          'svga'
        }
      />
      
      <div className="flex pt-28 h-screen overflow-hidden relative">
        <main className={`flex-1 overflow-y-auto transition-all duration-700 custom-scrollbar mr-0`}>
          <style>{`
            .no-scrollbar::-webkit-scrollbar {
              display: none;
            }
            .no-scrollbar {
              -ms-overflow-style: none;
              scrollbar-width: none;
            }
            .mask-edges {
              mask-image: linear-gradient(to right, transparent, black 2%, black 98%, transparent);
              -webkit-mask-image: linear-gradient(to right, transparent, black 2%, black 98%, transparent);
            }
            .animated-brand-text {
              background: linear-gradient(90deg, #6366f1, #a855f7, #ec4899, #3b82f6, #2dd4bf, #6366f1);
              background-size: 200% auto;
              color: transparent;
              background-clip: text;
              -webkit-background-clip: text;
              animation: colorGradient 4s linear infinite;
              filter: drop-shadow(0 2px 4px rgba(0,0,0,0.5)) drop-shadow(0 0 10px rgba(168,85,247,0.4));
            }
            @keyframes colorGradient {
              to { background-position: 200% center; }
            }
          `}</style>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-10">
            <Suspense fallback={<Loading />}>
            {state === AppState.IDLE && (
              <div className="py-10 animate-in fade-in zoom-in duration-700 w-[100vw] relative left-1/2 right-1/2 -ml-[50vw] -mr-[50vw]">
                <Dashboard 
                  onUpload={handleFileUpload} 
                  currentUser={currentUser}
                  onAction={(actionKey: string) => {
                     switch(actionKey) {
                        case 'animationManager': handleFeatureAccess(AppState.ANIMATION_MANAGER, 'Animation File Manager'); break;
                        case 'aiVideoMatting': handleFeatureAccess(AppState.AI_VIDEO_MATTING, 'AI Video Matting Studio'); break;
                        case 'videoConverter': handleFeatureAccess(AppState.VIDEO_CONVERTER, 'Video Converter'); break;
                        case 'universalConverter': handleFeatureAccess(AppState.UNIVERSAL_CONVERTER, 'Universal Motion Tools'); break;
                        case 'multiSvga': handleFeatureAccess(AppState.MULTI_SVGA_VIEWER, 'Multi SVGA Preview'); break;
                        case 'batchImageProcessor': handleFeatureAccess(AppState.BATCH_IMAGE_PROCESSOR, 'Batch Image Processor'); break;
                        case 'svgaBatchCompressor': handleFeatureAccess(AppState.SVGA_BATCH_COMPRESSOR, 'SVGA Batch Compressor'); break;
                        case 'svgaLayerEditor': handleFeatureAccess(AppState.SVGA_LAYER_EDITOR, 'SVGA Layer Editor'); break;
                        case 'batchCompress': handleFeatureAccess(AppState.BATCH_COMPRESSOR, 'Batch Compressor'); break;
                        case 'batchCropper': handleFeatureAccess(AppState.BATCH_CROPPER, 'Batch Cropper'); break;
                        case 'imageConverter': handleImageConverterOpen(); break;
                        case 'svgaEx': handleFeatureAccess(AppState.SVGA_EDITOR_EX, 'SVGA Editor EX'); break;
                        case 'store': setState(AppState.STORE); break;
                        case 'imageProcessor': handleFeatureAccess(AppState.IMAGE_PROCESSOR, 'Image Processor'); break;
                        case 'imageMatcher': handleFeatureAccess(AppState.IMAGE_MATCHER, 'Image Matcher'); break;
                        case 'imageEditor': handleFeatureAccess(AppState.IMAGE_EDITOR, 'Image Editor'); break;
                        case 'imageEnhancer': handleFeatureAccess(AppState.IMAGE_ENHANCER, 'AI Image Enhancer'); break;
                        case 'batchImageOpen': setShowBatchImage(true); break;
                        case 'name3DEditor': handleFeatureAccess(AppState.NAME_3D_EDITOR, '3D Name Editor'); break;
                        case 'audioExtractor': handleFeatureAccess(AppState.AUDIO_EXTRACTOR, 'Audio Extractor'); break;
                     }
                  }}
                />
              </div>
            )}
            {(state === AppState.PROCESSING || state === AppState.SVGA_EDITOR_EX) && fileMetadata && (
              <Workspace 
                key={fileMetadata.fileUrl}
                metadata={fileMetadata} 
                onCancel={handleReset} 
                settings={settings} 
                currentUser={currentUser} 
                onLoginRequired={() => {}}
                onSubscriptionRequired={() => setShowSubscriptionModal(true)}
                globalQuality={globalQuality}
                onFileReplace={(meta) => setFileMetadata(meta)}
                mode={state === AppState.SVGA_EDITOR_EX ? 'ex' : 'normal'}
                onImageConverterOpen={handleImageConverterOpen}
                onOpenLayerEditor={(file) => {
                  setLayerEditorInitialFile(file || fileMetadata?.originalFile || null);
                  handleFeatureAccess(AppState.SVGA_LAYER_EDITOR, 'SVGA Layer Editor');
                }}
              />
            )}
            {state === AppState.BATCH_COMPRESSOR && (
              <BatchCompressor 
                onCancel={handleReset} 
                currentUser={currentUser} 
                onLoginRequired={() => {}}
                onSubscriptionRequired={() => setShowSubscriptionModal(true)}
              />
            )}
            {state === AppState.SVGA_BATCH_COMPRESSOR && (
              <SvgaBatchCompressor 
                onCancel={handleReset} 
                currentUser={currentUser} 
                onSubscriptionRequired={() => setShowSubscriptionModal(true)}
              />
            )}
            {state === AppState.SVGA_LAYER_EDITOR && (
              <ErrorBoundary fallbackTitle="حدث خطأ في محرر طبقات SVGA" onReset={handleReset}>
                <SvgaLayerEditor 
                  initialFile={layerEditorInitialFile || fileMetadata?.originalFile || undefined}
                  onClose={() => {
                    if (fileMetadata) {
                      setState(AppState.PROCESSING);
                    } else {
                      handleReset();
                    }
                  }}
                  onOpenViewer={(exportedFile) => handleFileUpload([exportedFile])}
                />
              </ErrorBoundary>
            )}
            
            {state === AppState.VIDEO_CONVERTER && (
              <VideoConverter 
                currentUser={currentUser} 
                onCancel={handleReset} 
                onLoginRequired={() => {}}
                onSubscriptionRequired={() => setShowSubscriptionModal(true)}
                globalQuality={globalQuality}
                initialFiles={initialVideoFiles}
              />
            )}
            {state === AppState.UNIVERSAL_CONVERTER && (
              <ErrorBoundary fallbackTitle="حدث خطأ في محول الحركة الشامل" onReset={handleReset}>
                <UniversalMotionTools 
                  currentUser={currentUser} 
                  onCancel={handleReset} 
                  onLoginRequired={() => {}}
                  onSubscriptionRequired={() => setShowSubscriptionModal(true)}
                  initialFile={initialVapFile}
                  onOpenInWorkspace={(meta) => {
                    setFileMetadata(meta);
                    setState(AppState.PROCESSING);
                  }}
                />
              </ErrorBoundary>
            )}
            {state === AppState.IMAGE_CONVERTER && (
              <ImageToSvga 
                currentUser={currentUser} 
                onCancel={handleReset} 
                onLoginRequired={() => {}}
                onSubscriptionRequired={() => setShowSubscriptionModal(true)}
                globalQuality={globalQuality}
                initialFile={initialLottieFile}
              />
            )}
            {state === AppState.IMAGE_PROCESSOR && (
              <ImageProcessor 
                currentUser={currentUser} 
                onCancel={handleReset} 
                onSubscriptionRequired={() => setShowSubscriptionModal(true)}
              />
            )}
            {state === AppState.IMAGE_ENHANCER && (
              <ImageEnhancer 
                currentUser={currentUser} 
                onCancel={handleReset} 
                onSubscriptionRequired={() => setShowSubscriptionModal(true)}
              />
            )}
            {state === AppState.BATCH_IMAGE_PROCESSOR && (
              <BatchImageProcessor 
                onCancel={handleReset} 
                onSubscriptionRequired={() => setShowSubscriptionModal(true)}
              />
            )}
            {state === AppState.IMAGE_EDITOR && (
              <ImageEditor 
                currentUser={currentUser} 
                onCancel={handleReset} 
                onLoginRequired={() => {}}
                onSubscriptionRequired={() => setShowSubscriptionModal(true)}
              />
            )}
            {state === AppState.IMAGE_MATCHER && (
              <ImageMatcher 
                currentUser={currentUser} 
                onCancel={handleReset} 
                onLoginRequired={() => {}}
                onSubscriptionRequired={() => setShowSubscriptionModal(true)}
              />
            )}
            {state === AppState.BATCH_CROPPER && (
              <BatchCropper 
                currentUser={currentUser} 
                onCancel={handleReset} 
                onLoginRequired={() => {}}
                onSubscriptionRequired={() => setShowSubscriptionModal(true)}
              />
            )}
            {state === AppState.NAME_3D_EDITOR && (
              <Name3DEditor 
                onCancel={handleReset} 
                currentUser={currentUser}
                onSubscriptionRequired={() => setShowSubscriptionModal(true)}
              />
            )}
            {state === AppState.MULTI_SVGA_VIEWER && (
              <MultiSvgaViewer 
                onCancel={handleReset} 
                currentUser={currentUser}
                onSubscriptionRequired={() => setShowSubscriptionModal(true)}
                initialFiles={initialSvgaFiles}
              />
            )}
            {state === AppState.AUDIO_EXTRACTOR && (
              <AudioExtractor 
                currentUser={currentUser}
                onCancel={handleReset}
                onSubscriptionRequired={() => setShowSubscriptionModal(true)}
              />
            )}
            {state === AppState.AI_VIDEO_MATTING && (
              <AIVideoMattingStudio 
                currentUser={currentUser}
                onCancel={handleReset}
                onSubscriptionRequired={() => setShowSubscriptionModal(true)}
                initialVideoFile={fileMetadata?.originalFile || null}
              />
            )}
            {state === AppState.ANIMATION_MANAGER && (
              <AnimationManager onBack={handleReset} />
            )}
            {state === AppState.ADMIN_PANEL && (currentUser?.role === 'admin' || currentUser?.role === 'moderator') && (
              <AdminPanel currentUser={currentUser} onCancel={handleReset} />
            )}
            </Suspense>
          </div>
        </main>
      </div>

      <div className="fixed bottom-6 left-6 z-[100] flex flex-col-reverse gap-4">
        {state !== AppState.SVGA_LAYER_EDITOR && (
          <>
            {/* WhatsApp Floating Button */}
            {settings?.whatsappNumber && (
              <a 
                href={`https://wa.me/${settings.whatsappNumber}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-14 h-14 bg-[#25D366] hover:bg-[#20bd5a] text-white rounded-full flex items-center justify-center shadow-lg shadow-[#25D366]/30 transition-all hover:scale-110 hover:-translate-y-1 group"
                title="تواصل معنا عبر واتساب"
              >
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                </svg>
              </a>
            )}

            {/* Help Button */}
            <button 
              onClick={() => setShowOnboarding(true)}
              className="w-14 h-14 bg-blue-600 hover:bg-blue-500 text-white rounded-full flex items-center justify-center shadow-lg shadow-blue-600/30 transition-all hover:scale-110 hover:-translate-y-1 group cursor-pointer"
              title="شرح الموقع"
            >
              <HelpCircle className="w-8 h-8" />
            </button>

            {/* Features Guide Button */}
            <button 
              onClick={() => setShowFeaturesGuide(true)}
              className="w-14 h-14 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full flex items-center justify-center shadow-lg shadow-indigo-600/30 transition-all hover:scale-110 hover:-translate-y-1 group cursor-pointer"
              title="دليل الميزات"
            >
              <BookOpen className="w-7 h-7" />
            </button>
          </>
        )}
      </div>

      {showBatchImage && (
        <BatchImageConverter
          onClose={() => setShowBatchImage(false)}
        />
      )}

        

      {/* Onboarding Modal */}
      <OnboardingModal 
        isOpen={showOnboarding} 
        onClose={handleCloseOnboarding} 
      />

      {/* Subscription Modal */}
      <SubscriptionModal 
        isOpen={showSubscriptionModal}
        onClose={() => setShowSubscriptionModal(false)}
        settings={settings}
      />

      {/* Global Background App Update Notification */}
      <AppUpdateToast />

      {/* Version Blocked Modal */}
      {versionBlockedState.isBlocked && (
        <VersionBlockedModal
          requiredVersion={versionBlockedState.requiredVersion}
          installedVersion={versionBlockedState.installedVersion}
          userEmail={currentUser?.email}
          userId={currentUser?.id}
          onRetry={() => {
            const clientVer = getActiveClientVersion();
            const allowedVer = currentUser?.allowedVersion || settings?.defaultAllowedVersion || 'v3.0.0';
            const localCheck = checkVersionCompatibility(allowedVer, clientVer);
            if (localCheck.isAllowed) {
              setVersionBlockedState(prev => ({ ...prev, isBlocked: false }));
            }
          }}
        />
      )}
    </div>
  );
};

export default App;
